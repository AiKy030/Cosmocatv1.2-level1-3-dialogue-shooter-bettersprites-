# start_button_script.gd
extends Control

# Delete the line: 
# const Transition = preload("res://scenes/scene_fade_in_transition.tscn").new().get_script()


func _on_play_pressed():
	# 1. Define the path to the next scene
	const NEXT_SCENE_PATH = "res://scenes/world_2.tscn"
	
	# 2. Access the AutoLoad directly by its name and call the function.
	# 'Transition' is now a global object available everywhere.
	Transition.transition_to_scene(NEXT_SCENE_PATH)

func _on_quit_pressed():
	get_tree().quit()
