# finish_flag_script.gd
extends Area2D

# The path to the next level/scene is already an exported variable
@export var next_level: String = "res://scenes/level_3.tscn"


func _on_body_entered(body: Node2D) -> void:
	# 1. Stop Player Movement/Input
	# This prevents the player from moving during the 1.5s fade-out animation.
	if body.is_in_group("player"): # Using groups is more robust than checking 'body.name'
		if body.has_method("set_process_input"):
			body.set_process_input(false)
		# Assuming 'can_move' is the variable that controls player movement
		if body.has_method("set_can_move"):
			body.set_can_move(false)
		elif body.has_variable("can_move"):
			body.can_move = false

	# 2. Trigger the Global Transition
	# Assuming your AutoLoad is named 'Transition'
	# This single line executes the 1.5s Fade Out -> Scene Change -> 1.5s Fade In
	Transition.transition_to_scene(next_level)
	
	# 3. Disable this flag to prevent multiple triggers
	set_monitoring(false)
