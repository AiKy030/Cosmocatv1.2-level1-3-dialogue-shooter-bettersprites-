extends Area2D

@export var speed: float = 150.0
var direction: int = 1

func _ready():
	# Connect signals only once
	if not is_connected("body_entered", Callable(self, "_on_body_entered")):
		connect("body_entered", Callable(self, "_on_body_entered"))
	if not is_connected("area_entered", Callable(self, "_on_area_entered")):
		connect("area_entered", Callable(self, "_on_area_entered"))

func _physics_process(delta):
	position.x += speed * direction * delta

func _on_body_entered(body):
	if body.is_in_group("enemies"):
		body.die()
	queue_free()


func _on_area_entered(area):
	print("Bullet hit area:", area.name)
	queue_free()
