extends ParallaxBackground

@onready var camera = get_node("../Camera2D")

func _process(delta):
	if camera:
		scroll_offset = camera.position
