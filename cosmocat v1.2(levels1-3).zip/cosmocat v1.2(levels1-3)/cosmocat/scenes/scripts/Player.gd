extends CharacterBody2D

# --- START: ADDITIONS ---
var health: int = 3
var is_dead: bool = false # <-- This is the flag that stops actions
# --- END ADDITIONS ---
var input_vector: Vector2 = Vector2.ZERO
var can_move: bool = true
const SPEED = 130.0
const JUMP_VELOCITY = -300.0

@onready var bullet = preload("res://scenes/bullet.tscn")
@onready var animated_sprite = $AnimatedSprite2D
@onready var shoot_cooldown_manager = $ShootTimer
@onready var actionable_finder: Area2D = $Direction/ActionableFinder

func _unhandled_input(event: InputEvent) -> void:
	if Input.is_action_just_pressed("accept"):
		var actionables = actionable_finder.get_overlapping_areas()
		if actionables.size() > 0:
			actionables[0].action()
			return
	
	var x_axis: float = Input.get_axis("ui_left", "ui_right")
	var y_axis: float = Input.get_axis("ui_up", "ui_down")
	if x_axis:
		input_vector = x_axis * Vector2.RIGHT
	elif y_axis:
		input_vector = y_axis * Vector2.DOWN
	else:
		input_vector = Vector2.ZERO

# Function called when player is hit by an enemy
func take_damage(amount: int):
	# Prevents damage/restart if already dead
	if is_dead: 
		return
		
	health -= amount
	print("Player took damage. Health:", health)
	
	if health <= 0:
		die()

# Function called when player health reaches zero
func die():
	# 1. STOP ALL PLAYER MOVEMENT AND ACTIONS IMMEDIATELY
	is_dead = true
	can_move = false
	# set_process_input(false) is good, but the direct check below is more robust
	set_process_input(false) 
	
	# 2. Wait briefly for visual feedback before fade-out
	await get_tree().create_timer(1.0).timeout
	
	# 3. Trigger the transition to reload the CURRENT level (restarts the level)
	var current_scene_path = get_tree().current_scene.scene_file_path
	Transition.transition_to_scene(current_scene_path)


func shoot():
	# --- FIX: DIRECTLY CHECK THE DEATH FLAG HERE ---
	if is_dead:
		return # STOP execution if the player is dead
	# --- END FIX ---
	# --- CHANGE: Check the external cooldown script's flag ---
	if not shoot_cooldown_manager.can_fire:
		return
	# --- END CHANGE ---
	# Note: Because shoot() is called from _physics_process(), and _physics_process()
	# has an 'if not can_move: return' check, this is somewhat redundant, 
	# but essential if shoot() were ever called elsewhere or processed input directly.

	if Input.is_action_just_pressed("shoot"):
		shoot_cooldown_manager.start_cooldown()
		var b = bullet.instantiate()
		get_parent().add_child(b)
		b.position = position

		# Set bullet direction based on where player is facing
		if animated_sprite.flip_h:
			b.direction = -1 # Facing left
		else:
			b.direction = 1 # Facing right

func _physics_process(delta: float) -> void:
	if not can_move:
		return

	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Handle jump.
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Get the input direction and handle the movement/deceleration.
	var direction = Input.get_axis("move_left", "move_right")

	# Flips the sprite
	if direction > 0:
		animated_sprite.flip_h = false
	elif direction < 0:
		animated_sprite.flip_h = true

	# Play animations
	if is_on_floor():
		if direction == 0:
			animated_sprite.play("idle")
		else:
			animated_sprite.play("run")
	elif not is_on_floor():
		if velocity.y > 0:
			animated_sprite.play("fall")
		elif velocity.y < 0:
			animated_sprite.play("jump")

	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	shoot()
	move_and_slide()
