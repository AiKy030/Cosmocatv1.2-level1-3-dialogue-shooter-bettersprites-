# ShootCooldown.gd (Attached to the ShootTimer node)
extends Timer

# This flag tells the Player script whether it's okay to shoot
var can_fire: bool = true

func _ready():
	# Set the cooldown time (adjust this value as needed)
	self.wait_time = 2 
	self.one_shot = true 
	
	# Connect the signal. When the timer finishes, it resets the flag.
	timeout.connect(_on_timeout)

func start_cooldown():
	# --- FINAL FIX: Use time_left to check if the timer is running ---
	# If time_left is > 0, the timer is currently running.
	if time_left > 0:
		return
	# --- END FIX ---
	
	can_fire = false
	start()

func _on_timeout():
	# Called automatically when the timer finishes
	can_fire = true
