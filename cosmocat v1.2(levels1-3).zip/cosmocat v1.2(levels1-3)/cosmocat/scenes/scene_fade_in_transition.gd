# Transition.gd (Attached to the root node of scene_fade_in_transition.tscn)
extends CanvasLayer

@onready var anim_player = $ColorRect/AnimationPlayer
# Assuming "Fade-out" is your animation to go to black (opaque)
# and "Fade-in" is your animation to go to clear (transparent)
const FADE_OUT_ANIM = "Fade-out"
const FADE_IN_ANIM = "Fade-in"


# The function to call from any scene to start a transition
func transition_to_scene(path_to_new_scene: String) -> void:
	# 1. Start the Fade OUT (screen goes from clear to black)
	anim_player.play(FADE_OUT_ANIM)
	
	# 2. PAUSE execution and wait until the animation has finished. 
	# The screen is now fully black.
	await anim_player.animation_finished
	
	# 3. Change the scene while the screen is black
	var error = get_tree().change_scene_to_file(path_to_new_scene)
	if error != OK:
		push_error("Failed to load scene: ", path_to_new_scene)
		return
		
	# 4. Fade IN (screen goes from black to clear)
	anim_player.play(FADE_IN_ANIM)
	await anim_player.animation_finished
	
	# Optional: You can emit a signal here if other nodes need to know 
	# the transition is completely finished.


# Use _ready to fade in when the game first starts (or the scene is first loaded)
func _ready():
	# Only fade in if we're not already playing a transition
	if not anim_player.is_playing():
		anim_player.play(FADE_IN_ANIM)
